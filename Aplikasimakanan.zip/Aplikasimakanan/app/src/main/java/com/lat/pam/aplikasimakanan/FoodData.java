package com.lat.pam.aplikasimakanan;

import android.content.Context;
import android.graphics.drawable.Drawable;

import com.lat.pam.aplikasimakanan.R;

import java.util.ArrayList;

public class FoodData {
    public static ArrayList<Food> getData(Context context) {
        ArrayList<Food> list = new ArrayList<Food>();
        list.add(new Food("Nasi Goreng", "Nasi Goreng biasa dengan toping sosis, bakso, udang, dan telur ceplok.", 23000, context.getDrawable(R.drawable.nasigoreng)));
        list.add(new Food("Mie Goreng", "Mie Goreng manis dengan resep khas dan berbagai rempah pilihan", 18000, context.getDrawable(R.drawable.mie_goreng)));
        list.add(new Food("Cireng ", "Cireng dengan isian daging cingcang dengan saus khas", 12000, context.getDrawable(R.drawable.cireng)));
        list.add(new Food("Batagor ", "Batagor ialah makanan khas Bandung, isi 5pcs", 10000, context.getDrawable(R.drawable.batagor)));
        list.add(new Food("Sparkling Tea", "Tea yang sangat nikmat untuk menemani makanan yang lain", 8000, context.getDrawable(R.drawable.sparkling_tea)));
        return list;
    }
}
